<nav class="navbar">
    <div class="navbar-container">
        <!-- LOGO -->
        <div class="logo">
            <svg class="logo-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">
                <circle cx="32" cy="32" r="30" fill="url(#grad)" stroke="#fff" stroke-width="2"/>
                <path d="M20 20 L32 52 L44 20 Z" fill="#fff" opacity="0.9"/>
                <circle cx="28" cy="30" r="2" fill="#ff4500"/>
                <circle cx="36" cy="34" r="2" fill="#ff0099"/>
                <circle cx="32" cy="40" r="2" fill="#00ffff"/>
                <defs>
                    <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" style="stop-color:#ff0099; stop-opacity:1"/>
                        <stop offset="100%" style="stop-color:#00ffff; stop-opacity:1"/>
                    </linearGradient>
                </defs>
            </svg>
            <span>Pizzaria FuTuRiSTa</span>
        </div>

        <!-- MENU -->
        <ul class="menu-links">
            <li><a href="index.php">Início</a></li>
            <li><a href="sobre.php">Sobre</a></li>
            <li><a href="cardapio.php">Cardápio</a></li>
            <li><a href="concluir.php">Comanda</a></li>
            <li><a href="contato.php">Contato</a></li>
        </ul>
    </div>
</nav>

<style>
/* =================== NAVBAR BASE =================== */
.navbar {
    background: rgba(10, 10, 25, 0.95);
    box-shadow: 0 0 25px rgba(0, 255, 255, 0.3);
    padding: 15px 40px;
    position: sticky;
    top: 0;
    z-index: 1000;
}

.navbar-container {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

/* =================== LOGO FUTURISTA =================== */
.logo {
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 1.8rem;
    font-weight: 900;
    text-transform: uppercase;
    background: linear-gradient(90deg, #ff0099, #00ffff);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    animation: logo-glow 4s ease-in-out infinite alternate;
    cursor: default;
}

.logo-icon {
    width: 50px;
    height: 50px;
    filter: drop-shadow(0 0 10px #ff0099) drop-shadow(0 0 15px #00ffff);
    animation: spin-slow 10s linear infinite;
}

/* =================== BOTÕES FUTURISTAS =================== */
.menu-links {
    display: flex;
    gap: 20px;
    list-style: none;
}

.menu-links li a {
    text-decoration: none;
    color: #6a0a44ff;
    box-shadow: 1px 1px 3px white;
    border-color: black;
    font-weight: 600;
    padding: 10px 22px;
    border: 2px solid #0eb7f0ff;
    border-radius: 15px;
    transition: all 0.1s ease;
    position: relative;
    overflow: hidden;
    display: inline-block;
}

/* Gradiente animado ao hover */
.menu-links li a::before {
    content: '';
    position: absolute;
    width: 0;
    height: 100%;
    top: 0;
    left: 0;
    background: linear-gradient(120deg, #8aececff, #00ffff, #5a7ee0ff, #091fa8ff);
    transition: all 0.4s ease;
    z-index: -1;
}

/* Expande o gradiente no hover */
.menu-links li a:hover::before {
    width: 100%;
}

/* Hover principal */
.menu-links li a:hover {
    color: black;
    transform: scale(0.9);
    box-shadow: 0 0 30px #40047bff;
}

.menu-links li a {
    animation: pulse 2.5s infinite;
}

/* =================== ANIMAÇÕES =================== */


@keyframes logo-glow {
    from { text-shadow: 0 0 5px #ff0099, 0 0 10px #00ffff; }
    to { text-shadow: 0 0 20px #00ffff, 0 0 30px #ff0099; }
}

@keyframes spin-slow {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}
</style>
