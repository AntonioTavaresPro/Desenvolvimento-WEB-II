<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Sobre - Pizzaria FuTuRiSTa</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* =================== HERO FUTURISTA =================== */
        .hero-sobre {
            background: linear-gradient(135deg, #ff4500, #ff0099, #00ffff);
            background-size: 300% 300%;
            animation: gradientMove 8s ease infinite;
            color: #fff;
            text-align: center;
            padding: 80px 20px;
        }

        .hero-sobre h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
            text-transform: uppercase;
        }

        .hero-sobre p {
            font-size: 1.2rem;
            max-width: 700px;
            margin: 0 auto;
        }

        @keyframes gradientMove {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        /* =================== SEÇÃO SOBRE =================== */
        .content {
            border: 2px solid transparent;
            border-radius: 12px;
            padding: 30px;
            margin: 40px auto;
            background: rgba(0,0,0,0.7);
            max-width: 900px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .content::before {
            content: "";
            position: absolute;
            inset: 0;
            border-radius: 12px;
            padding: 2px;
            background: linear-gradient(90deg, #ff4500, #ff0099, #00ffff, #ff4500);
            -webkit-mask: 
                linear-gradient(#000 0 0) content-box, 
                linear-gradient(#000 0 0);
            -webkit-mask-composite: xor;
                    mask-composite: exclude;
            animation: neon-border 6s linear infinite;
            pointer-events: none;
        }

        .content h2 {
            font-size: 2rem;
            margin-bottom: 15px;
            color: #ff4500;
        }

        .content p {
            font-size: 1.1rem;
            line-height: 1.6;
            color: #ddd;
        }

        /* =================== DESTAQUES =================== */
        .highlights {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }

        .highlight-box {
            background: rgba(20,20,20,0.9);
            padding: 20px;
            border-radius: 10px;
            border: 2px solid #ff4500;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .highlight-box:hover {
            transform: translateY(-5px);
            box-shadow: 0 0 15px #ff4500, 0 0 25px #ff0099;
        }

        .highlight-box h3 {
            color: #ff0099;
            margin-bottom: 10px;
        }

        .highlight-box p {
            color: #ccc;
            font-size: 0.95rem;
        }

        /* =================== ANIMAÇÃO DA BORDA =================== */
        @keyframes neon-border {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
    </style>
</head>
<body>
    <?php include 'menu.php'; ?>

    <!-- Hero Futurista -->
    <section class="hero-sobre">
        <h1>Sobre a Pizzaria FuTuRiSTa</h1>
        <p>A união perfeita entre tradição italiana e inovação futurista no coração da sua mesa.</p>
    </section>

    <!-- Conteúdo Sobre -->
    <section class="content">
        <h2>Quem Somos</h2>
        <p>Somos a primeira pizzaria 100% digital do Brasil, trazendo praticidade e sabor futurista para sua mesa. 
        Nossas receitas combinam a tradição italiana com inovação tecnológica, garantindo qualidade, agilidade e muito sabor em cada fatia.</p>

        <div class="highlights">
            <div class="highlight-box">
                <h3>🍕 Nossa Missão</h3>
                <p>Levar experiências gastronômicas únicas, mesclando sabor, inovação e acessibilidade para todos os clientes.</p>
            </div>
            <div class="highlight-box">
                <h3>🚀 Nossa Visão</h3>
                <p>Ser referência nacional em pizzaria digital, unindo tecnologia de ponta e tradição culinária.</p>
            </div>
            <div class="highlight-box">
                <h3>💡 Nossos Valores</h3>
                <p>Qualidade, inovação, transparência e paixão por surpreender nossos clientes.</p>
            </div>
        </div>
    </section>
</body>
</html>
