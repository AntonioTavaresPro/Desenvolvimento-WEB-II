<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pizzaria FuTuRiSTa</title>
    <!-- Mantém seu CSS original -->
    <link rel="stylesheet" href="style.css">
    
    <!-- CSS adicional para hero, overlay e botão -->
    <style>
        /* ===================== HERO ===================== */
        .hero {
            position: relative;
            background-image: url('IMAGENS/FUNDOPG.png'); /* Substitua pelo caminho da sua imagem */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            border-radius: 150px;
            height: 44vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: white;
            text-align: center;
            background-attachment: fixed; /* parallax leve */
        }

        .hero::before {
            content: "";
            position: absolute;
            top: 0;
            border-radius: 150px;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5); /* overlay semitransparente */
            z-index: 1;
        }

        .hero-content {
            position: relative;
            z-index: 2; /* conteúdo acima do overlay */
            margin-top: 13px;
        }

        .btn-explorar {
            background-color: #ff4500;
            color: white;
            padding: 13px 26px;
            text-decoration: none;
            border-radius: 33px;
            transition: 0.3s;
            font-weight: bold;
            margin-top: 277px;
            display: inline-block;
        }

        .btn-explorar:hover {
            background-color: #e03e00;
        }
    </style>
</head>
<body>
    <?php include 'menu.php'; ?>

    <!-- HERO -->
    <div class="hero">
        <div class="hero-content">
            <h1>Bem-vindo à Pizzaria FuTuiRiSTa</h1>
            <p>Experiência gastronômica única e saborosa. Sinta-se em casa!</p>
            <a href="cardapio.php" class="btn-explorar">Explorar o Menu</a>
        </div>
    </div>

    <!-- SOBRE -->
    <section class="about-section">
        <h2>Quem Somos</h2>
        <p>Nosso restaurante oferece uma culinária diversificada, com pizzas elaboradas com ingredientes frescos e de alta qualidade. Seja para um almoço rápido ou um jantar especial, temos a opção perfeita para você.</p>
        <a href="sobre.php" class="btn-saber-mais">Saiba Mais</a>
    </section>

    <!-- DEPOIMENTOS -->
    <section class="reviews-section">
        <h2>O que nossos clientes dizem</h2>
        <div class="reviews">
            <div class="review">
                <p>"A pizza é maravilhosa, o ambiente é acolhedor e o atendimento é impecável. Recomendo a todos!"</p>
                <span>- Maria Silva</span>
            </div>
            <div class="review">
                <p>"Uma experiência única. A pizza estava deliciosa e o atendimento super atencioso. Voltarei com certeza!"</p>
                <span>- João Souza</span>
            </div>
        </div>
    </section>

    <!-- LOCALIZAÇÃO -->
    <section class="location-section">
        <h2>Visite-nos</h2>
        <p>Estamos localizados na Rua das Flores, 123, Centro. Venha nos fazer uma visita e aproveite nossa cozinha deliciosa!</p>
        <a href="contato.php" class="btn-visit">Como Chegar</a>
    </section>

    <!-- RODAPÉ -->
    <footer>
        <p>&copy; 2025 Pizzaria FuTuRiSTa - Desenvolvedor: Antonio Tavares</p>
    </footer>
</body>
</html>
