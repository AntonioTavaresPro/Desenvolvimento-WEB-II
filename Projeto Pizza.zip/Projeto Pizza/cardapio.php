<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Cardápio - Pizzaria FuTuRiSTa</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* =================== HERO FUTURISTA =================== */
        .hero-cardapio {
            background: linear-gradient(135deg, #ff4500, #ff0099, #00ffff);
            background-size: 300% 300%;
            animation: gradientMove 8s ease infinite;
            color: #fff;
            text-align: center;
            padding: 80px 20px;
        }

        .hero-cardapio h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
            text-transform: uppercase;
        }

        .hero-cardapio p {
            font-size: 1.2rem;
            max-width: 700px;
            margin: 0 auto;
        }

        @keyframes gradientMove {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        /* =================== CONTEÚDO =================== */
        .content {
            border: 2px solid transparent;
            border-radius: 12px;
            padding: 30px;
            margin: 40px auto;
            background: rgba(0,0,0,0.75);
            max-width: 1000px;
            position: relative;
            overflow: hidden;
        }

        .content::before {
            content: "";
            position: absolute;
            inset: 0;
            border-radius: 12px;
            padding: 2px;
            background: linear-gradient(90deg, #ff4500, #ff0099, #00ffff, #ff4500);
            -webkit-mask: 
                linear-gradient(#000 0 0) content-box, 
                linear-gradient(#000 0 0);
            -webkit-mask-composite: xor;
                    mask-composite: exclude;
            animation: neon-border 6s linear infinite;
            pointer-events: none;
        }

        .content h2 {
            font-size: 2rem;
            margin-bottom: 15px;
            text-align: center;
            color: #ff4500;
        }

        .content p {
            text-align: center;
            color: #ccc;
            margin-bottom: 25px;
        }

        /* =================== FORMULÁRIO =================== */
        .pedido-form {
            display: grid;
            gap: 20px;
        }

        .pedido-form label {
            font-weight: bold;
            color: #ff0099;
            margin-top: 10px;
        }

        .pedido-form input[type="text"],
        .pedido-form select,
        .pedido-form input[type="number"] {
            width: 100%;
            padding: 10px;
            border-radius: 8px;
            border: 1px solid #ff0099;
            background: rgba(30,30,30,0.9);
            color: #fff;
            font-size: 1rem;
            transition: box-shadow 0.3s ease, border 0.3s ease;
        }

        .pedido-form input:focus,
        .pedido-form select:focus {
            box-shadow: 0 0 10px #ff0099, 0 0 20px #00ffff;
            border: 1px solid #00ffff;
        }

        /* =================== GRUPOS DE ITENS =================== */
        .item-group {
            background: rgba(20,20,20,0.9);
            border: 1px solid #444;
            border-radius: 10px;
            padding: 15px;
            margin-top: 10px;
        }

        .item {
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 8px 0;
            padding: 10px;
            border-radius: 8px;
            transition: background 0.3s ease, transform 0.2s ease;
        }

        .item:hover {
            background: rgba(255,69,0,0.15);
            transform: translateX(5px);
        }

        .item label {
            flex: 1;
            color: #ddd;
        }

        .item span {
            font-weight: bold;
            color: #ff4500;
        }

        .item small {
            display: block;
            font-size: 0.9rem;
            color: #aaa;
        }

        /* =================== BOTÃO FINAL =================== */
        .pedido-form button {
            background: linear-gradient(90deg, #ff0099, #00ffff);
            color: #fff;
            border: none;
            padding: 14px;
            font-size: 1.1rem;
            border-radius: 8px;
            cursor: pointer;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            margin-top: 20px;
        }

        .pedido-form button:hover {
            transform: scale(1.05);
            box-shadow: 0 0 15px #ff0099, 0 0 25px #00ffff;
        }

        /* =================== ANIMAÇÃO DA BORDA =================== */
        @keyframes neon-border {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
    </style>
</head>
<body>
    <?php include 'menu.php'; ?>

    <!-- Hero Futurista -->
    <section class="hero-cardapio">
        <h1>Nosso Cardápio</h1>
        <p>Monte seu pedido com sabores clássicos, especiais, doces e muito mais 🚀</p>
    </section>

    <!-- Conteúdo Cardápio -->
    <section class="content">
        <h2>🍕 Monte seu pedido 🍕</h2>
        <p>Escolha seus sabores, adicione extras e bebidas, e defina as quantidades!</p>

        <form action="concluir.php" method="POST" class="pedido-form">

            <!-- Nome do cliente -->
            <label for="cliente">Nome do Cliente:</label>
            <input type="text" name="cliente" id="cliente" required>

            <!-- Tamanho da pizza -->
            <label for="tamanho">Tamanho da Pizza:</label>
            <select name="tamanho" id="tamanho" required>
                <option value="Pequena">Pequena – preço base</option>
                <option value="Média">Média – +R$10,00</option>
                <option value="Grande">Grande – +R$20,00</option>
            </select>

            <!-- Pizzas Clássicas -->
            <h3>Pizzas Clássicas</h3>
            <div class="item-group pizzas-classicas">
                <?php
                $pizzas = [
                    "Mussarela"=>"Tradicional queijo derretido e molho especial",
                    "Calabresa"=>"Calabresa fatiada com cebola roxa",
                    "Portuguesa"=>"Presunto, ovos, azeitonas e cebola"
                ];
                foreach($pizzas as $sabor => $desc) {
                    $preco = ($sabor=="Mussarela"?30:($sabor=="Calabresa"?32:35));
                    echo '<div class="item">';
                    echo '<input type="checkbox" name="pizza['.$sabor.'][check]" id="'.$sabor.'">';
                    echo '<label for="'.$sabor.'"><span>'.$sabor.' – R$'.$preco.',00</span><small>'.$desc.'</small></label>';
                    echo '<input type="number" name="pizza['.$sabor.'][qtd]" value="1" min="1">';
                    echo '</div>';
                }
                ?>
            </div>

            <!-- Pizzas Especiais -->
            <h3>Pizzas Especiais</h3>
            <div class="item-group pizzas-especiais">
                <?php
                $pizzasEspeciais = [
                    "Frango com Catupiry"=>"Frango desfiado com catupiry",
                    "Quatro Queijos"=>"Mussarela, parmesão, gorgonzola e provolone",
                    "Pepperoni"=>"Pepperoni crocante"
                ];
                foreach($pizzasEspeciais as $sabor => $desc) {
                    $preco = ($sabor=="Frango com Catupiry"?38:($sabor=="Quatro Queijos"?40:42));
                    echo '<div class="item">';
                    echo '<input type="checkbox" name="pizza['.$sabor.'][check]" id="'.$sabor.'">';
                    echo '<label for="'.$sabor.'"><span>'.$sabor.' – R$'.$preco.',00</span><small>'.$desc.'</small></label>';
                    echo '<input type="number" name="pizza['.$sabor.'][qtd]" value="1" min="1">';
                    echo '</div>';
                }
                ?>
            </div>

            <!-- Pizzas Doces -->
            <h3>Pizzas Doces</h3>
            <div class="item-group pizzas-doces">
                <?php
                $pizzasDoces = [
                    "Chocolate"=>"Chocolate ao leite com granulados",
                    "Romeu e Julieta"=>"Goiabada cremosa com queijo minas"
                ];
                foreach($pizzasDoces as $sabor => $desc) {
                    $preco = ($sabor=="Chocolate"?36:38);
                    echo '<div class="item">';
                    echo '<input type="checkbox" name="pizza['.$sabor.'][check]" id="'.$sabor.'">';
                    echo '<label for="'.$sabor.'"><span>'.$sabor.' – R$'.$preco.',00</span><small>'.$desc.'</small></label>';
                    echo '<input type="number" name="pizza['.$sabor.'][qtd]" value="1" min="1">';
                    echo '</div>';
                }
                ?>
            </div>

            <!-- Borda Recheada -->
            <h3>Borda Recheada</h3>
            <div class="item-group borda">
                <div class="item">
                    <input type="radio" name="borda" value="Sim" id="bordaSim" required>
                    <label for="bordaSim">Sim (+R$5,00)</label>
                </div>
                <div class="item">
                    <input type="radio" name="borda" value="Não" id="bordaNao" required>
                    <label for="bordaNao">Não</label>
                </div>
            </div>

            <!-- Extras -->
            <h3>Extras</h3>
            <div class="item-group extras">
                <?php
                $extras = ["Molho de Alho"=>3, "Molho Picante"=>3, "Batata Frita"=>10];
                foreach($extras as $extra => $preco) {
                    echo '<div class="item">';
                    echo '<input type="checkbox" name="extras['.$extra.'][check]" id="'.$extra.'">';
                    echo '<label for="'.$extra.'">'.$extra.' (+R$'.$preco.')</label>';
                    echo '<input type="number" name="extras['.$extra.'][qtd]" value="1" min="1">';
                    echo '</div>';
                }
                ?>
            </div>

            <!-- Bebidas -->
            <h3>Bebidas</h3>
            <div class="item-group bebidas">
                <?php
                $bebidas = ["Refrigerante"=>8, "Suco"=>12, "Água"=>5];
                foreach($bebidas as $bebida => $preco) {
                    echo '<div class="item">';
                    echo '<input type="checkbox" name="bebidas['.$bebida.'][check]" id="'.$bebida.'">';
                    echo '<label for="'.$bebida.'">'.$bebida.' (+R$'.$preco.')</label>';
                    echo '<input type="number" name="bebidas['.$bebida.'][qtd]" value="1" min="1">';
                    echo '</div>';
                }
                ?>
            </div>

            <!-- Botão Concluir Pedido -->
            <button type="submit">Concluir Pedido</button>

        </form>
    </section>
</body>
</html>
