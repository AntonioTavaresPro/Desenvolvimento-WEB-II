<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Comanda - Pizzaria FuTuRiSTa</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Botão Fazer Pedido */
        .btn-pedido {
            display: inline-block;
            padding: 15px 30px;
            background: linear-gradient(135deg, #00ffea, #ff00ff);
            color: #111;
            font-weight: bold;
            border-radius: 12px;
            cursor: pointer;
            margin-top: 20px;
            transition: transform 0.2s, box-shadow 0.3s;
        }
        .btn-pedido:hover {
            transform: scale(1.05);
            box-shadow: 0 0 15px #ff00ff;
        }

        /* Formulário de pagamento/entrega */
        #pedido-form {
            display: none;
            margin-top: 30px;
            padding: 20px;
            border: 2px solid #00ffea;
            border-radius: 12px;
            background: #111;
            box-shadow: 0 0 15px #ff00ff55;
        }
        #pedido-form h3 {
            color: #00ffea;
            margin-bottom: 15px;
            border-bottom: 2px solid #ff00ff;
            padding-bottom: 5px;
        }
        #pedido-form input[type="text"],
        #pedido-form select {
            width: 100%;
            padding: 12px;
            margin: 8px 0;
            border-radius: 10px;
            border: 2px solid #00ffea;
            background: #111;
            color: #fff;
            font-size: 16px;
        }
        #pedido-form button {
            padding: 12px 25px;
            background: linear-gradient(135deg, #00ffea, #ff00ff);
            border: none;
            border-radius: 12px;
            color: #111;
            font-weight: bold;
            cursor: pointer;
            margin-top: 10px;
            transition: transform 0.2s, box-shadow 0.3s;
        }
        #pedido-form button:hover {
            transform: scale(1.05);
            box-shadow: 0 0 15px #ff00ff;
        }
    </style>
    <script>
        function mostrarPedidoForm() {
            const form = document.getElementById('pedido-form');
            form.style.display = form.style.display === 'block' ? 'none' : 'block';
        }
    </script>
    
</head>
<body>
    <?php include 'menu.php'; ?>

    <section class="content resumo">
        <h2>Resumo do Pedido</h2>
        <?php
        $cliente = $_POST['cliente'] ?? 'Não informado';
        $tamanho = $_POST['tamanho'] ?? 'Não selecionado';
        $borda = $_POST['borda'] ?? 'Não selecionada';
        $pizzas = $_POST['pizza'] ?? [];
        $extras = $_POST['extras'] ?? [];
        $bebidas = $_POST['bebidas'] ?? [];

        $precosPizzas = [
            "Mussarela"=>30, "Calabresa"=>32, "Portuguesa"=>35,
            "Frango com Catupiry"=>38, "Quatro Queijos"=>40, "Pepperoni"=>42,
            "Chocolate"=>36, "Romeu e Julieta"=>38
        ];
        $precosExtras = ["Molho de Alho"=>3, "Molho Picante"=>3, "Batata Frita"=>10];
        $precosBebidas = ["Refrigerante"=>8, "Suco"=>12, "Água"=>5];
        $precosTamanho = ["Pequena"=>0, "Média"=>10, "Grande"=>20];

        $total = 0;

        echo "<p><strong>Cliente:</strong> $cliente</p>";
        echo "<p><strong>Tamanho da Pizza:</strong> $tamanho</p>";

        // Pizzas
        echo "<h3>Pizzas:</h3><ul>";
        if(!empty($pizzas)) {
            foreach($pizzas as $sabor => $dados) {
                if(isset($dados['check'])){
                    $qtd = (int)$dados['qtd'];
                    $subtotal = ($precosPizzas[$sabor] + $precosTamanho[$tamanho]) * $qtd;
                    $total += $subtotal;
                    echo "<li>$qtd x $sabor – R$$subtotal,00</li>";
                }
            }
        } else {
            echo "<li>Nenhuma pizza selecionada</li>";
        }
        echo "</ul>";

        // Borda
        echo "<h3>Borda Recheada:</h3><p>$borda</p>";
        if($borda=="Sim") $total += 5;

        // Extras
        echo "<h3>Extras:</h3><ul>";
        if(!empty($extras)){
            foreach($extras as $extra=>$dados){
                if(isset($dados['check'])){
                    $qtd = (int)$dados['qtd'];
                    $subtotal = $precosExtras[$extra]*$qtd;
                    $total += $subtotal;
                    echo "<li>$qtd x $extra – R$$subtotal,00</li>";
                }
            }
        } else { echo "<li>Nenhum extra selecionado</li>"; }
        echo "</ul>";

        // Bebidas
        echo "<h3>Bebidas:</h3><ul>";
        if(!empty($bebidas)){
            foreach($bebidas as $bebida=>$dados){
                if(isset($dados['check'])){
                    $qtd = (int)$dados['qtd'];
                    $subtotal = $precosBebidas[$bebida]*$qtd;
                    $total += $subtotal;
                    echo "<li>$qtd x $bebida – R$$subtotal,00</li>";
                }
            }
        } else { echo "<li>Nenhuma bebida selecionada</li>"; }
        echo "</ul>";

        echo "<h2>Total a pagar: R$ $total,00</h2>";
        ?>

        <!-- Botão Fazer Pedido -->
        <button class="btn-pedido" onclick="mostrarPedidoForm()">Fazer Pedido</button>

        <!-- Formulário de Pagamento e Entrega -->
        <div id="pedido-form">
            <h3>Pagamento e Entrega</h3>
            <form action="finalizar_pedido.php" method="POST">
                <input type="hidden" name="total" value="<?php echo $total; ?>">
                <label>Endereço de Entrega:</label>
                <input type="text" name="endereco" placeholder="Rua, Número, Bairro" required>
                
                <label>Forma de Pagamento:</label>
                <select name="pagamento" required>
                    <option value="">Selecione...</option>
                    <option value="Dinheiro">Dinheiro</option>
                    <option value="Cartão de Crédito">Cartão de Crédito</option>
                    <option value="Pix">PIX</option>
                </select>

                <button type="submit">Finalizar Pedido</button>
            </form>
        </div>
    </section>
</body>
</html>
