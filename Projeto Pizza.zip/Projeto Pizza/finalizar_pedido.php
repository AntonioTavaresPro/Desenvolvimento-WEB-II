<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Pedido Finalizado - Pizzaria FuTuRiSTa</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .success-container {
            max-width: 700px;
            margin: 50px auto;
            padding: 40px;
            border-radius: 15px;
            background: linear-gradient(135deg, #111, #1a1a1a);
            border: 2px solid #00ffea;
            box-shadow: 0 0 25px #ff00ff77;
            text-align: center;
            color: #fff;
        }

        .success-container h1 {
            color: #00ffea;
            font-size: 36px;
            margin-bottom: 20px;
            animation: pulse 1.5s infinite;
        }

        .success-container p {
            font-size: 18px;
            margin-bottom: 25px;
        }

        .btn-voltar {
            padding: 12px 25px;
            background: linear-gradient(135deg, #00ffea, #ff00ff);
            color: #111;
            font-weight: bold;
            border-radius: 12px;
            text-decoration: none;
            transition: transform 0.2s, box-shadow 0.3s;
        }

        .btn-voltar:hover {
            transform: scale(1.05);
            box-shadow: 0 0 15px #ff00ff;
        }

        @keyframes pulse {
            0% { text-shadow: 0 0 10px #00ffea; }
            50% { text-shadow: 0 0 25px #ff00ff; }
            100% { text-shadow: 0 0 10px #00ffea; }
        }
    </style>
</head>
<body>
    <?php include 'menu.php'; ?>

    <section class="success-container">
        <h1>🎉 Pedido realizado com sucesso! 🎉</h1>
        <p>Seu pedido foi recebido e está sendo preparado.</p>
        <p>Acompanhe seu pedido pelo número de comanda ou aguarde nosso contato.</p>

        <?php
        if(isset($_POST['total']) && !empty($_POST['total'])){
            echo "<p><strong>Total do Pedido:</strong> R$ " . $_POST['total'] . ",00</p>";
        }
        if(isset($_POST['endereco']) && !empty($_POST['endereco'])){
            echo "<p><strong>Endereço de Entrega:</strong> " . htmlspecialchars($_POST['endereco']) . "</p>";
        }
        if(isset($_POST['pagamento']) && !empty($_POST['pagamento'])){
            echo "<p><strong>Forma de Pagamento:</strong> " . htmlspecialchars($_POST['pagamento']) . "</p>";
        }
        ?>
        <a href="index.php" class="btn-voltar">Voltar à Página Inicial</a>
    </section>
</body>
</html>
