<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Contato - Pizzaria FuTuRiSTa</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* =================== HERO FUTURISTA =================== */
        .hero-contato {
            background: linear-gradient(135deg, #ff4500, #ff0099, #00ffff);
            background-size: 300% 300%;
            animation: gradientMove 8s ease infinite;
            color: #fff;
            text-align: center;
            padding: 80px 20px;
        }

        .hero-contato h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
            text-transform: uppercase;
        }

        .hero-contato p {
            font-size: 1.2rem;
            max-width: 700px;
            margin: 0 auto;
        }

        @keyframes gradientMove {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        /* =================== CONTEÚDO =================== */
        .content {
            border: 2px solid transparent;
            border-radius: 12px;
            padding: 30px;
            margin: 40px auto;
            background: rgba(0,0,0,0.7);
            max-width: 900px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .content::before {
            content: "";
            position: absolute;
            inset: 0;
            border-radius: 12px;
            padding: 2px;
            background: linear-gradient(90deg, #ff4500, #ff0099, #00ffff, #ff4500);
            -webkit-mask: 
                linear-gradient(#000 0 0) content-box, 
                linear-gradient(#000 0 0);
            -webkit-mask-composite: xor;
                    mask-composite: exclude;
            animation: neon-border 6s linear infinite;
            pointer-events: none;
        }

        .content h2 {
            font-size: 2rem;
            margin-bottom: 15px;
            color: #ff4500;
        }

        /* =================== FORMULÁRIO =================== */
        .contact-form {
            display: grid;
            gap: 15px;
            margin-top: 20px;
            text-align: left;
        }

        .contact-form label {
            font-weight: bold;
            color: #ff0099;
        }

        .contact-form input,
        .contact-form textarea {
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            border: none;
            outline: none;
            background: rgba(30,30,30,0.9);
            color: #fff;
            font-size: 1rem;
            border: 1px solid #ff0099;
            transition: box-shadow 0.3s ease, border 0.3s ease;
        }

        .contact-form input:focus,
        .contact-form textarea:focus {
            box-shadow: 0 0 10px #ff0099, 0 0 20px #00ffff;
            border: 1px solid #00ffff;
        }

        .contact-form button {
            background: linear-gradient(90deg, #ff0099, #00ffff);
            color: #fff;
            border: none;
            padding: 12px;
            font-size: 1.1rem;
            border-radius: 8px;
            cursor: pointer;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .contact-form button:hover {
            transform: scale(1.05);
            box-shadow: 0 0 15px #ff0099, 0 0 25px #00ffff;
        }

        /* =================== INFORMAÇÕES =================== */
        .contact-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-top: 30px;
            text-align: center;
        }

        .info-box {
            background: rgba(20,20,20,0.9);
            padding: 20px;
            border-radius: 10px;
            border: 2px solid #ff4500;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .info-box:hover {
            transform: translateY(-5px);
            box-shadow: 0 0 15px #ff4500, 0 0 25px #ff0099;
        }

        .info-box h3 {
            color: #ff0099;
            margin-bottom: 10px;
        }

        .info-box p {
            color: #ccc;
            font-size: 0.95rem;
        }

        /* =================== ANIMAÇÃO DA BORDA =================== */
        @keyframes neon-border {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
    </style>
</head>
<body>
    <?php include 'menu.php'; ?>

    <!-- Hero Futurista -->
    <section class="hero-contato">
        <h1>Entre em Contato</h1>
        <p>Tem dúvidas, sugestões ou deseja fazer um pedido especial? Fale com a gente!</p>
    </section>

    <!-- Conteúdo Contato -->
    <section class="content">
        <h2>Fale Conosco</h2>
        <form action="enviar_contato.php" method="POST" class="contact-form">
            <label for="nome">Nome:</label>
            <input type="text" id="nome" name="nome" required>

            <label for="email">E-mail:</label>
            <input type="email" id="email" name="email" required>

            <label for="mensagem">Mensagem:</label>
            <textarea id="mensagem" name="mensagem" rows="5" required></textarea>

            <button type="submit">Enviar Mensagem</button>
        </form>

        <div class="contact-info">
            <div class="info-box">
                <h3>📍 Endereço</h3>
                <p>Rua da Inovação, 123 - São Paulo, SP</p>
            </div>
            <div class="info-box">
                <h3>📞 Telefone</h3>
                <p>(11) 99999-9999</p>
            </div>
            <div class="info-box">
                <h3>⏰ Horário</h3>
                <p>Seg a Dom: 18h - 23h</p>
            </div>
        </div>
    </section>
</body>
</html>
