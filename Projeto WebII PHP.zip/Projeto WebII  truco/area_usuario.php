<?php
session_start();

if (!isset($_SESSION['nome']) || !isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Área do Usuário</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <section class="section">
            <h2>Bem-vindo, <?= htmlspecialchars($_SESSION['nome']) ?>!</h2>
            <p><strong>E-mail:</strong> <?= htmlspecialchars($_SESSION['email']) ?></p>
            <h2>Obrigado pelos ensinamentos Profiii!</h2>
            <form method="POST" action="logout.php">
                <button class="form" type="submit">Logout</button>
            </form>
        </section>
    </div>
</body>
</html>
