<?php
session_start();

$cookie_email = $_COOKIE['email_usuario'] ?? '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST['email']);
    $senha = trim($_POST['senha']);

    if (file_exists("usuarios.txt")) {
        $usuarios = file("usuarios.txt", FILE_IGNORE_NEW_LINES);

        foreach ($usuarios as $linha) {
            list($nomeSalvo, $emailSalvo, $senhaSalva) = explode("|", $linha);

            if ($email === $emailSalvo && $senha === $senhaSalva) {
                $_SESSION['nome'] = $nomeSalvo;
                $_SESSION['email'] = $emailSalvo;

                header("Location: area_usuario.php");
                exit();
            }
        }
        $erro = "E-mail ou senha incorretos.";
    } else {
        $erro = "Nenhum usuário cadastrado ainda.";
    }
}

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Tela de Login</h2>
        <?php if (!empty($erro)) echo "<p class='error'>$erro</p>"; ?>

        <form method="POST">
            <input type="email" name="email" placeholder="E-mail" value="<?= htmlspecialchars($cookie_email) ?>" required>
            <input type="password" name="senha" placeholder="Senha" required>
            <button type="submit">Entrar</button>
        </form>

        <p>Não tem conta? <a href="cadastro.php">Cadastre-se aqui</a></p>
    </div>
</body>
</html>
