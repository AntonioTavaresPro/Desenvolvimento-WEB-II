<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nome = trim($_POST['nome']);
    $email = trim($_POST['email']);
    $senha = trim($_POST['senha']);

    if ($nome && $email && $senha) {
        $linha = "$nome|$email|$senha\n";
        file_put_contents("usuarios.txt", $linha, FILE_APPEND);

        setcookie("email_usuario", $email, time() + 3600, "/");

        header("Location: login.php");
        exit();
    } else {
        $erro = "Por favor, preencha todos os campos.";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastro</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Cadastro de Usuário</h2>
        <?php if (!empty($erro)) echo "<p class='error'>$erro</p>"; ?>

        <form method="POST">
            <input type="text" name="nome" placeholder="Nome" required>
            <input type="email" name="email" placeholder="E-mail" required>
            <input type="password" name="senha" placeholder="Senha" required>
            <button type="submit">Salvar</button>
        </form>

        <p>Já tem conta? <a href="login.php">Ir para Login</a></p>
    </div>
</body>
</html>
