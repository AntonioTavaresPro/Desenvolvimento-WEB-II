<?php
require_once __DIR__ . '/conexao.php';
function require_login($nivel_necessario = null) {
    if (!isset($_SESSION['usuario_id'])) {
        header('Location: /login.php');
        exit;
    }
    if ($nivel_necessario !== null && $_SESSION['nivel'] !== $nivel_necessario) {
        if ($_SESSION['nivel'] === 'admin') header('Location: /admin/dashboard.php');
        else header('Location: /usuario/index.php');
        exit;
    }
}
?>