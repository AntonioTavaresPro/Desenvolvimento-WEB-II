<?php
require 'config/conexao.php';
if (isset($_SESSION['usuario_id'])) {
    if ($_SESSION['nivel'] === 'admin') header('Location: admin/dashboard.php');
    else header('Location: usuario/index.php');
    exit;
}

$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $senha = trim($_POST['senha']);

    if ($email === '' || $senha === '') {
        $erro = 'Preencha todos os campos.';
    } else {
        $stmt = $pdo->prepare('SELECT * FROM usuarios WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        $u = $stmt->fetch();
        if ($u && password_verify($senha, $u['senha'])) {
            $_SESSION['usuario_id'] = $u['id'];
            $_SESSION['usuario_nome'] = $u['nome'];
            $_SESSION['nivel'] = $u['nivel'];
            $_SESSION['foto'] = $u['foto'];
            if ($u['nivel'] === 'admin') header('Location: admin/dashboard.php');
            else header('Location: usuario/index.php');
            exit;
        } else {
            $erro = 'Email ou senha inválidos.';
        }
    }
}
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Login</title></head>
<body>
<h2>Login</h2>
<?php if ($erro): ?><p style="color:red"><?php echo $erro ?></p><?php endif; ?>
<form method="post">
    <label>Email:<br><input type="email" name="email"></label><br><br>
    <label>Senha:<br><input type="password" name="senha"></label><br><br>
    <button type="submit">Entrar</button>
</form>
<p><a href="contato.php">Fale conosco</a></p>
</body>
</html>