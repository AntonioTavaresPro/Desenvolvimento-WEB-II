<?php
require_once __DIR__ . '/../config/conexao.php';
if (!isset($_SESSION['usuario_id']) || $_SESSION['nivel'] !== 'usuario') {
    header('Location: /login.php');
    exit;
}
$id = $_GET['id'] ?? null;
$stmt = $pdo->prepare('SELECT * FROM produtos WHERE id = ?');
$stmt->execute([$id]);
$produto = $stmt->fetch();
if (!$produto) {
    echo 'Produto não encontrado';
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Location: avaliacao.php?id=' . $produto['id']);
    exit;
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Checkout</title></head><body>
<h2>Checkout - <?php echo htmlspecialchars($produto['nome']) ?></h2>
<p>Preço: <?php echo number_format($produto['preco'],2,',','.') ?></p>
<form method="post">
    <p>Confirme a compra:</p>
    <button type="submit">Finalizar Compra</button>
</form>
</body></html>