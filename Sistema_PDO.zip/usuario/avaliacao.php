<?php
require_once __DIR__ . '/../config/conexao.php';
if (!isset($_SESSION['usuario_id']) || $_SESSION['nivel'] !== 'usuario') {
    header('Location: /login.php');
    exit;
}
$id_produto = $_GET['id'] ?? null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $comentario = $_POST['comentario'] ?? '';
    $nota = (int)($_POST['nota'] ?? 0);
    if ($comentario && $nota>0) {
        $stmt = $pdo->prepare('INSERT INTO avaliacoes (id_usuario,id_produto,comentario,nota) VALUES (?,?,?,?)');
        $stmt->execute([$_SESSION['usuario_id'],$id_produto,$comentario,$nota]);
        echo '<p>Avaliação enviada. <a href="index.php">Voltar</a></p>';
        exit;
    } else {
        $erro = 'Preencha comentário e nota.';
    }
}
$stmt = $pdo->prepare('SELECT * FROM produtos WHERE id = ?');
$stmt->execute([$id_produto]);
$produto = $stmt->fetch();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Avaliação</title></head><body>
<h2>Avaliar produto: <?php echo htmlspecialchars($produto['nome']) ?></h2>
<?php if (isset($erro)) echo '<p style="color:red">' . $erro . '</p>'; ?>
<form method="post">
    <label>Comentário:<br><textarea name="comentario"></textarea></label><br>
    <label>Nota (1-5):<br><input type="number" name="nota" min="1" max="5"></label><br><br>
    <button type="submit">Enviar Avaliação</button>
</form>
</body></html>