<?php
require_once __DIR__ . '/../config/conexao.php';
if (!isset($_SESSION['usuario_id']) || $_SESSION['nivel'] !== 'usuario') {
    header('Location: /login.php');
    exit;
}
$produtos = $pdo->query('SELECT * FROM produtos')->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Usuário - Index</title></head><body>
<header>
    <h2>Bem-vindo, <?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></h2>
    <img src="<?php echo htmlspecialchars($_SESSION['foto']); ?>" width="50" alt="foto">
    <p><a href="../logout.php">Sair</a></p>
</header>
<h3>Produtos / Serviços</h3>
<table border="1"><tr><th>Nome</th><th>Preço</th><th>Ações</th></tr>
<?php foreach($produtos as $p): ?>
<tr>
    <td><?php echo htmlspecialchars($p['nome']) ?></td>
    <td><?php echo number_format($p['preco'],2,',','.') ?></td>
    <td><a href="checkout.php?id=<?php echo $p['id'] ?>">Comprar</a></td>
</tr>
<?php endforeach; ?>
</table>
</body></html>