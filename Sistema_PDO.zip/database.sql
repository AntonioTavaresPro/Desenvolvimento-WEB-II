-- database.sql
CREATE DATABASE IF NOT EXISTS sistema_pdo CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sistema_pdo;

CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100),
  email VARCHAR(100) UNIQUE,
  senha VARCHAR(255),
  nivel ENUM('admin','usuario') DEFAULT 'usuario',
  foto VARCHAR(255) DEFAULT 'assets/img/default.png'
);

CREATE TABLE IF NOT EXISTS produtos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100),
  descricao TEXT,
  preco DECIMAL(10,2) DEFAULT 0.00
);

CREATE TABLE IF NOT EXISTS avaliacoes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  id_usuario INT,
  id_produto INT,
  comentario TEXT,
  nota INT,
  FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE,
  FOREIGN KEY (id_produto) REFERENCES produtos(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS contatos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100),
  email VARCHAR(100),
  mensagem TEXT
);

-- inserir usuários de exemplo (senhas já com hash)
INSERT INTO usuarios (nome,email,senha,nivel,foto) VALUES
('Eulaliane','eulaliane@fatec.com','$2b$12$8VDoQj6HFnHuYocB4o.LvesFqXtj1SiVlHWCIucD3hTVHqfrLN0S.','admin','assets/img/default.png'),
('Antonio','antonio@fatec.com','$2b$12$agou.bAauhxah0iS6TR14uLsSeORWlGhEpi4/0eWzMJejml2UQ7iS','usuario','assets/img/default.png');

-- inserir produtos exemplo
INSERT INTO produtos (nome,descricao,preco) VALUES
('Serviço A','Descrição do Serviço A', 100.00),
('Produto B','Descrição do Produto B', 49.90);
