<?php
require_once __DIR__ . '/../config/conexao.php';
if (!isset($_SESSION['usuario_id']) || $_SESSION['nivel'] !== 'admin') {
    header('Location: /login.php');
    exit;
}
$acao = $_GET['acao'] ?? '';
if ($acao === 'excluir' && isset($_GET['id'])) {
    $stmt = $pdo->prepare('DELETE FROM produtos WHERE id = ?');
    $stmt->execute([$_GET['id']]);
    header('Location: produtos.php');
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'] ?? '';
    $desc = $_POST['descricao'] ?? '';
    $preco = $_POST['preco'] ?? 0;
    if ($nome) {
        $stmt = $pdo->prepare('INSERT INTO produtos (nome,descricao,preco) VALUES (?,?,?)');
        $stmt->execute([$nome,$desc,$preco]);
        header('Location: produtos.php');
        exit;
    }
}
$produtos = $pdo->query('SELECT * FROM produtos')->fetchAll();
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Admin - Produtos</title></head><body>
<h2>Serviços / Produtos</h2>
<p><a href="dashboard.php">Voltar</a> | <a href="produtos.php?acao=novo">Novo Produto</a></p>
<?php if (isset($_GET['acao']) && $_GET['acao'] === 'novo'): ?>
    <h3>Novo Produto</h3>
    <form method="post">
        <label>Nome:<br><input name="nome"></label><br>
        <label>Descrição:<br><textarea name="descricao"></textarea></label><br>
        <label>Preço:<br><input name="preco" type="number" step="0.01"></label><br><br>
        <button type="submit">Salvar</button>
    </form>
<?php else: ?>
    <table border="1" cellpadding="5">
        <tr><th>ID</th><th>Nome</th><th>Preço</th><th>Ações</th></tr>
        <?php foreach($produtos as $p): ?>
            <tr>
                <td><?php echo $p['id'] ?></td>
                <td><?php echo htmlspecialchars($p['nome']) ?></td>
                <td><?php echo number_format($p['preco'],2,',','.') ?></td>
                <td>
                    <a href="produtos.php?acao=excluir&id=<?php echo $p['id'] ?>" onclick="return confirm('Excluir?')">Excluir</a>
                    | <a href="../usuario/checkout.php?id=<?php echo $p['id'] ?>">Ver (checkout)</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
<?php endif; ?>
</body></html>