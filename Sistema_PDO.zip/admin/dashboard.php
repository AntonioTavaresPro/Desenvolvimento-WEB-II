<?php
require_once __DIR__ . '/../config/conexao.php';
if (!isset($_SESSION['usuario_id']) || $_SESSION['nivel'] !== 'admin') {
    header('Location: /login.php');
    exit;
}
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Admin - Dashboard</title></head>
<body>
<header>
    <h2>Dashboard - Admin</h2>
    <p>Olá, <?php echo htmlspecialchars($_SESSION['usuario_nome']); ?> <img src="<?php echo htmlspecialchars($_SESSION['foto']); ?>" alt="foto" width="50"></p>
    <p><a href="usuarios.php">Usuários</a> | <a href="produtos.php">Serviços/Produtos</a> | <a href="avaliacoes.php">Avaliações</a> | <a href="contatos.php">Contatos</a> | <a href="../logout.php">Sair</a></p>
</header>
<main>
    <p>Aqui você pode gerenciar o sistema.</p>
</main>
</body>
</html>