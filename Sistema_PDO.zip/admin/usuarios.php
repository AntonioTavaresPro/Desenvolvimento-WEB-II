<?php
require_once __DIR__ . '/../config/conexao.php';
if (!isset($_SESSION['usuario_id']) || $_SESSION['nivel'] !== 'admin') {
    header('Location: /login.php');
    exit;
}
$acao = $_GET['acao'] ?? '';
if ($acao === 'excluir' && isset($_GET['id'])) {
    $stmt = $pdo->prepare('DELETE FROM usuarios WHERE id = ?');
    $stmt->execute([$_GET['id']]);
    header('Location: usuarios.php');
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'] ?? '';
    $email = $_POST['email'] ?? '';
    $senha = $_POST['senha'] ?? '';
    $nivel = $_POST['nivel'] ?? 'usuario';
    $foto = $_POST['foto'] ?? 'assets/img/default.png';
    if ($nome && $email) {
        if ($senha) $hash = password_hash($senha, PASSWORD_DEFAULT);
        else $hash = password_hash('123456', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare('INSERT INTO usuarios (nome,email,senha,nivel,foto) VALUES (?,?,?,?,?)');
        $stmt->execute([$nome,$email,$hash,$nivel,$foto]);
        header('Location: usuarios.php');
        exit;
    }
}
$usuarios = $pdo->query('SELECT id,nome,email,nivel,foto FROM usuarios')->fetchAll();
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Admin - Usuários</title></head><body>
<h2>Usuários</h2>
<p><a href="dashboard.php">Voltar</a> | <a href="usuarios.php?acao=novo">Novo Usuário</a></p>
<?php if (isset($_GET['acao']) && $_GET['acao'] === 'novo'): ?>
    <h3>Novo Usuário</h3>
    <form method="post">
        <label>Nome:<br><input name="nome"></label><br>
        <label>Email:<br><input name="email" type="email"></label><br>
        <label>Senha (opcional):<br><input name="senha" type="password"></label><br>
        <label>Nível:<br>
            <select name="nivel">
                <option value="usuario">usuario</option>
                <option value="admin">admin</option>
            </select>
        </label><br>
        <label>Foto (url):<br><input name="foto" value="assets/img/default.png"></label><br><br>
        <button type="submit">Salvar</button>
    </form>
<?php else: ?>
    <table border="1" cellpadding="5">
        <tr><th>ID</th><th>Nome</th><th>Email</th><th>Nível</th><th>Ações</th></tr>
        <?php foreach($usuarios as $u): ?>
            <tr>
                <td><?php echo $u['id'] ?></td>
                <td><?php echo htmlspecialchars($u['nome']) ?></td>
                <td><?php echo htmlspecialchars($u['email']) ?></td>
                <td><?php echo $u['nivel'] ?></td>
                <td>
                    <a href="usuarios.php?acao=excluir&id=<?php echo $u['id'] ?>" onclick="return confirm('Excluir?')">Excluir</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
<?php endif; ?>
</body></html>