<?php
require_once __DIR__ . '/../config/conexao.php';
if (!isset($_SESSION['usuario_id']) || $_SESSION['nivel'] !== 'admin') {
    header('Location: /login.php');
    exit;
}
if (isset($_GET['excluir']) && isset($_GET['id'])) {
    $stmt = $pdo->prepare('DELETE FROM avaliacoes WHERE id = ?');
    $stmt->execute([$_GET['id']]);
    header('Location: avaliacoes.php');
    exit;
}
$avaliacoes = $pdo->query('SELECT a.*, u.nome as usuario_nome, p.nome as produto_nome FROM avaliacoes a JOIN usuarios u ON a.id_usuario = u.id JOIN produtos p ON a.id_produto = p.id ORDER BY a.id DESC')->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Avaliações</title></head><body>
<h2>Avaliações</h2>
<p><a href="dashboard.php">Voltar</a></p>
<table border="1" cellpadding="5">
<tr><th>ID</th><th>Usuário</th><th>Produto</th><th>Nota</th><th>Comentário</th><th>Ações</th></tr>
<?php foreach($avaliacoes as $a): ?>
<tr>
    <td><?php echo $a['id'] ?></td>
    <td><?php echo htmlspecialchars($a['usuario_nome']) ?></td>
    <td><?php echo htmlspecialchars($a['produto_nome']) ?></td>
    <td><?php echo $a['nota'] ?></td>
    <td><?php echo htmlspecialchars($a['comentario']) ?></td>
    <td><a href="avaliacoes.php?excluir=1&id=<?php echo $a['id'] ?>" onclick="return confirm('Excluir?')">Excluir</a></td>
</tr>
<?php endforeach; ?>
</table>
</body></html>