<?php
require_once __DIR__ . '/../config/conexao.php';
if (!isset($_SESSION['usuario_id']) || $_SESSION['nivel'] !== 'admin') {
    header('Location: /login.php');
    exit;
}
if (isset($_GET['excluir']) && isset($_GET['id'])) {
    $stmt = $pdo->prepare('DELETE FROM contatos WHERE id = ?');
    $stmt->execute([$_GET['id']]);
    header('Location: contatos.php');
    exit;
}
$contatos = $pdo->query('SELECT * FROM contatos ORDER BY id DESC')->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Contatos</title></head><body>
<h2>Mensagens de Contato</h2>
<p><a href="dashboard.php">Voltar</a></p>
<table border="1"><tr><th>ID</th><th>Nome</th><th>Email</th><th>Mensagem</th><th>Ações</th></tr>
<?php foreach($contatos as $c): ?>
<tr>
    <td><?php echo $c['id'] ?></td>
    <td><?php echo htmlspecialchars($c['nome']) ?></td>
    <td><?php echo htmlspecialchars($c['email']) ?></td>
    <td><?php echo htmlspecialchars($c['mensagem']) ?></td>
    <td><a href="contatos.php?excluir=1&id=<?php echo $c['id'] ?>" onclick="return confirm('Excluir?')">Excluir</a></td>
</tr>
<?php endforeach; ?>
</table>
</body></html>