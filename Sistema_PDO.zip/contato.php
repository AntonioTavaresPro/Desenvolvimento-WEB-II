<?php
require 'config/conexao.php';
$ok = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'] ?? '';
    $email = $_POST['email'] ?? '';
    $mensagem = $_POST['mensagem'] ?? '';
    if ($nome && $email && $mensagem) {
        $stmt = $pdo->prepare('INSERT INTO contatos (nome,email,mensagem) VALUES (?,?,?)');
        $stmt->execute([$nome,$email,$mensagem]);
        $ok = 'Mensagem enviada. Obrigado!';
    } else {
        $ok = 'Preencha todos os campos.';
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Contato</title></head><body>
<h2>Contato</h2>
<?php if ($ok) echo '<p>' . htmlspecialchars($ok) . '</p>'; ?>
<form method="post">
    <label>Nome:<br><input name="nome"></label><br>
    <label>Email:<br><input name="email" type="email"></label><br>
    <label>Mensagem:<br><textarea name="mensagem"></textarea></label><br><br>
    <button type="submit">Enviar</button>
</form>
<p><a href="login.php">Entrar</a></p>
</body></html>