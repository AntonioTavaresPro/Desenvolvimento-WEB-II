<?php

$quiz = [

    "Geografia" => [
        [
            'pergunta' => 'Qual a capital do Brasil?',
            'opcoes' => ['São Paulo', 'Rio de Janeiro', 'Brasília', 'Salvador'],
            'resposta_correta' => 'Brasília'
        ],
        [
            'pergunta' => 'Qual o maior país em extensão territorial?',
            'opcoes' => ['China', 'Canadá', 'Rússia', 'Estados Unidos'],
            'resposta_correta' => 'Rússia'
        ],
        [
            'pergunta' => 'O deserto do Saara está localizado em qual continente?',
            'opcoes' => ['África', 'Ásia', 'América do Sul', 'Oceania'],
            'resposta_correta' => 'África'
        ],
        [
            'pergunta' => 'Qual o rio mais extenso do mundo?',
            'opcoes' => ['Amazonas', 'Nilo', 'Yangtzé', 'Mississippi'],
            'resposta_correta' => 'Amazonas'
        ],
        [
            'pergunta' => 'Em que país fica a Torre Eiffel?',
            'opcoes' => ['Itália', 'França', 'Alemanha', 'Inglaterra'],
            'resposta_correta' => 'França'
        ],
    ],

    "Matemática" => [
        [
            'pergunta' => 'Quanto é 7 x 8?',
            'opcoes' => ['54', '56', '58', '60'],
            'resposta_correta' => '56'
        ],
        [
            'pergunta' => 'Qual é a raiz quadrada de 81?',
            'opcoes' => ['7', '8', '9', '10'],
            'resposta_correta' => '9'
        ],
        [
            'pergunta' => 'Qual é o valor de π (pi) aproximado?',
            'opcoes' => ['2,14', '3,14', '3,41', '4,13'],
            'resposta_correta' => '3,14'
        ],
        [
            'pergunta' => 'Se um triângulo tem lados iguais, ele é:',
            'opcoes' => ['Escaleno', 'Isósceles', 'Equilátero', 'Retângulo'],
            'resposta_correta' => 'Equilátero'
        ],
        [
            'pergunta' => 'Quanto é 12 ÷ 3?',
            'opcoes' => ['2', '3', '4', '6'],
            'resposta_correta' => '4'
        ],
    ],

    "Tecnologia" => [
        [
            'pergunta' => 'Quem é considerado o “pai da computação”?',
            'opcoes' => ['Bill Gates', 'Alan Turing', 'Steve Jobs', 'Linus Torvalds'],
            'resposta_correta' => 'Alan Turing'
        ],
        [
            'pergunta' => 'Qual linguagem é usada para estruturar páginas web?',
            'opcoes' => ['CSS', 'HTML', 'JavaScript', 'Python'],
            'resposta_correta' => 'HTML'
        ],
        [
            'pergunta' => 'O que significa “CPU”?',
            'opcoes' => ['Central Process Unit', 'Central Processing Unit', 'Control Processing Unit', 'Computer Personal Unit'],
            'resposta_correta' => 'Central Processing Unit'
        ],
        [
            'pergunta' => 'Quem criou o sistema operacional Linux?',
            'opcoes' => ['Bill Gates', 'Steve Jobs', 'Linus Torvalds', 'Mark Zuckerberg'],
            'resposta_correta' => 'Linus Torvalds'
        ],
        [
            'pergunta' => 'Qual empresa desenvolveu o Windows?',
            'opcoes' => ['Apple', 'Microsoft', 'Google', 'IBM'],
            'resposta_correta' => 'Microsoft'
        ],
    ],

    "Português" => [
        [
            'pergunta' => 'Qual é o plural de "cidadão"?',
            'opcoes' => ['Cidadãos', 'Cidadões', 'Cidadães', 'Cidões'],
            'resposta_correta' => 'Cidadãos'
        ],
        [
            'pergunta' => 'Qual destas palavras está escrita corretamente?',
            'opcoes' => ['Excessão', 'Exceção', 'Exsseção', 'Exeção'],
            'resposta_correta' => 'Exceção'
        ],
        [
            'pergunta' => 'Em "os meninos estudam", qual é o sujeito?',
            'opcoes' => ['os', 'meninos', 'estudam', 'os meninos'],
            'resposta_correta' => 'os meninos'
        ],
        [
            'pergunta' => 'Qual é o antônimo de "triste"?',
            'opcoes' => ['Feliz', 'Bravo', 'Doente', 'Cansado'],
            'resposta_correta' => 'Feliz'
        ],
        [
            'pergunta' => 'Qual a classe gramatical da palavra "rápido" em "Ele corre rápido"?',
            'opcoes' => ['Substantivo', 'Adjetivo', 'Advérbio', 'Verbo'],
            'resposta_correta' => 'Advérbio'
        ],
    ],

    "Conhecimentos Gerais" => [
        [
            'pergunta' => 'Qual é o planeta mais próximo do Sol?',
            'opcoes' => ['Vênus', 'Terra', 'Mercúrio', 'Marte'],
            'resposta_correta' => 'Mercúrio'
        ],
        [
            'pergunta' => 'Qual é o metal cujo símbolo químico é Au?',
            'opcoes' => ['Prata', 'Ouro', 'Alumínio', 'Cobre'],
            'resposta_correta' => 'Ouro'
        ],
        [
            'pergunta' => 'Em que ano o homem pisou na Lua pela primeira vez?',
            'opcoes' => ['1965', '1969', '1971', '1975'],
            'resposta_correta' => '1969'
        ],
        [
            'pergunta' => 'Quem pintou a Mona Lisa?',
            'opcoes' => ['Michelangelo', 'Leonardo da Vinci', 'Rafael', 'Donatello'],
            'resposta_correta' => 'Leonardo da Vinci'
        ],
        [
            'pergunta' => 'Quantos continentes existem?',
            'opcoes' => ['4', '5', '6', '7'],
            'resposta_correta' => '6'
        ],
    ],

    "Física" => [
        [
            'pergunta' => 'Qual é a unidade de medida da força?',
            'opcoes' => ['Watt', 'Joule', 'Newton', 'Pascal'],
            'resposta_correta' => 'Newton'
        ],
        [
            'pergunta' => 'Qual partícula possui carga negativa?',
            'opcoes' => ['Próton', 'Nêutron', 'Elétron', 'Fóton'],
            'resposta_correta' => 'Elétron'
        ],
        [
            'pergunta' => 'Quem formulou a Teoria da Relatividade?',
            'opcoes' => ['Newton', 'Galileu', 'Einstein', 'Bohr'],
            'resposta_correta' => 'Einstein'
        ],
        [
            'pergunta' => 'A velocidade da luz no vácuo é de aproximadamente:',
            'opcoes' => ['300 mil km/s', '150 mil km/s', '30 mil km/s', '3 mil km/s'],
            'resposta_correta' => '300 mil km/s'
        ],
        [
            'pergunta' => 'Qual é a fórmula da segunda lei de Newton?',
            'opcoes' => ['E = mc²', 'F = m.a', 'V = d/t', 'P = m.g'],
            'resposta_correta' => 'F = m.a'
        ],
    ],
    
    "História" => [
        [
            'pergunta' => 'Quem foi o primeiro presidente do Brasil?',
            'opcoes' => ['Getúlio Vargas', 'Deodoro da Fonseca', 'Dom Pedro II', 'Floriano Peixoto'],
            'resposta_correta' => 'Deodoro da Fonseca'
        ],
        [
            'pergunta' => 'Em que ano ocorreu a independência do Brasil?',
            'opcoes' => ['1820', '1822', '1830', '1889'],
            'resposta_correta' => '1822'
        ],
        [
            'pergunta' => 'Quem descobriu o Brasil em 1500?',
            'opcoes' => ['Cristóvão Colombo', 'Pedro Álvares Cabral', 'Vasco da Gama', 'Fernão de Magalhães'],
            'resposta_correta' => 'Pedro Álvares Cabral'
        ],
        [
            'pergunta' => 'Qual foi o país colonizador do Brasil?',
            'opcoes' => ['Espanha', 'França', 'Portugal', 'Inglaterra'],
            'resposta_correta' => 'Portugal'
        ],
        [
            'pergunta' => 'Quem foi chamado de “Pai da Aviação”?',
            'opcoes' => ['Wright Brothers', 'Santos Dumont', 'Leonardo da Vinci', 'Charles Lindbergh'],
            'resposta_correta' => 'Santos Dumont'
        ],
    ],

    "Química" => [
        [
            'pergunta' => 'Qual é o símbolo químico da água?',
            'opcoes' => ['O2', 'H2O', 'CO2', 'HO'],
            'resposta_correta' => 'H2O'
        ],
        [
            'pergunta' => 'Qual gás os seres humanos expiram?',
            'opcoes' => ['Oxigênio', 'Gás Carbônico', 'Nitrogênio', 'Hidrogênio'],
            'resposta_correta' => 'Gás Carbônico'
        ],
        [
            'pergunta' => 'Qual elemento tem o símbolo "Na"?',
            'opcoes' => ['Sódio', 'Nióbio', 'Níquel', 'Neônio'],
            'resposta_correta' => 'Sódio'
        ],
        [
            'pergunta' => 'Qual ácido é encontrado no suco gástrico?',
            'opcoes' => ['Ácido acético', 'Ácido sulfúrico', 'Ácido clorídrico', 'Ácido cítrico'],
            'resposta_correta' => 'Ácido clorídrico'
        ],
        [
            'pergunta' => 'Qual é o número atômico do oxigênio?',
            'opcoes' => ['6', '7', '8', '9'],
            'resposta_correta' => '8'
        ],
    ],

    "Biologia" => [
        [
            'pergunta' => 'Qual é a unidade básica da vida?',
            'opcoes' => ['Célula', 'Tecido', 'Órgão', 'Molécula'],
            'resposta_correta' => 'Célula'
        ],
        [
            'pergunta' => 'Qual órgão é responsável por bombear o sangue?',
            'opcoes' => ['Pulmão', 'Fígado', 'Coração', 'Rim'],
            'resposta_correta' => 'Coração'
        ],
        [
            'pergunta' => 'Qual vitamina é produzida pela pele com exposição ao sol?',
            'opcoes' => ['Vitamina A', 'Vitamina B', 'Vitamina C', 'Vitamina D'],
            'resposta_correta' => 'Vitamina D'
        ],
        [
            'pergunta' => 'Qual é o maior órgão do corpo humano?',
            'opcoes' => ['Coração', 'Fígado', 'Pele', 'Pulmão'],
            'resposta_correta' => 'Pele'
        ],
        [
            'pergunta' => 'Qual grupo de seres vivos produz seu próprio alimento pela fotossíntese?',
            'opcoes' => ['Animais', 'Plantas', 'Fungos', 'Vírus'],
            'resposta_correta' => 'Plantas'
        ],
    ],
];
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Quiz Interativo</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php

if (!isset($_POST['tema']) && !isset($_POST['respostas'])) {

    echo "<h2>Escolha um tema para iniciar o Quiz</h2>";
    echo "<form method='post'>";
    echo "<select name='tema' required>";
    echo "<option value=''>-- Selecione --</option>";
    foreach ($quiz as $tema => $perguntas) {
        echo "<option value='$tema'>$tema</option>";
    }
    echo "</select>";
    echo "<button type='submit'>Iniciar</button>";
    echo "</form>";

} elseif (isset($_POST['tema']) && !isset($_POST['respostas'])) {

    $tema = $_POST['tema'];
    echo "<h2>Quiz de $tema</h2>";
    echo "<form method='post'>";
    foreach ($quiz[$tema] as $index => $questao) {
        echo "<p><b>" . ($index + 1) . ") " . $questao['pergunta'] . "</b></p>";
        foreach ($questao['opcoes'] as $opcao) {
            echo "<label><input type='radio' name='respostas[$index]' value='$opcao' required> $opcao</label><br>";
        }
        echo "<br>";
    }
    echo "<input type='hidden' name='tema' value='$tema'>";
    echo "<button type='submit'>Enviar Respostas</button>";
    echo "</form>";

} elseif (isset($_POST['respostas'])) {

    $tema = $_POST['tema'];
    $respostas = $_POST['respostas'];
    $acertos = 0;
    $total = count($quiz[$tema]);

    echo "<h2>Resultado do Quiz de $tema</h2>";
    foreach ($quiz[$tema] as $index => $questao) {
        $respostaUsuario = $respostas[$index] ?? null;
        $correta = $questao['resposta_correta'];

        echo "<p><b>" . ($index + 1) . ") " . $questao['pergunta'] . "</b></p>";

        foreach ($questao['opcoes'] as $opcao) {
            $classe = "";
            if ($opcao === $correta) {
                $classe = "correta";
            } elseif ($opcao === $respostaUsuario && $respostaUsuario !== $correta) {
                $classe = "errada";
            }
            $checked = ($respostaUsuario === $opcao) ? "checked" : "";
            echo "<label class='$classe'><input type='radio' disabled $checked> $opcao</label><br>";
        }
        echo "<br>";

        if ($respostaUsuario === $correta) {
            $acertos++;
        }
    }

    $nota = ($acertos / $total) * 10;

    if ($nota == 10) {
        $mensagem = "🎉 Excelente! Você gabaritou!";
    } elseif ($nota >= 7) {
        $mensagem = "😊 Muito bem, bom desempenho!";
    } elseif ($nota >= 4) {
        $mensagem = "😐 Você pode melhorar, continue praticando.";
    } else {
        $mensagem = "😢 Precisa estudar mais. Não desista!";
    }

    echo "
    <div id='resultadoModal' class='modal'>
        <div class='modal-content'>
            <span class='fechar'>&times;</span>
            <h2>Resultado do Quiz</h2>
            <p>Você acertou <b>$acertos</b> de <b>$total</b> perguntas.</p>
            <p>Sua pontuação foi: <b>" . number_format($nota, 1) . "</b> / 10</p>

            <!-- Barra de progresso -->
            <div class='barra-container'>
                <div id='barraProgresso' class='barra'></div>
            </div>

            <p>$mensagem</p>
            <form method='post'>
                <button type='submit'>Jogar Novamente</button>
            </form>
        </div>
    </div>

    <script>
    // abrir modal automaticamente
    window.onload = function() {
        document.getElementById('resultadoModal').style.display = 'flex';

        // animar barra de progresso
        let barra = document.getElementById('barraProgresso');
        let nota = $nota; // pega a nota calculada no PHP
        let largura = 0;
        let cor = '#f44336'; // vermelho padrão

        if (nota >= 7) cor = '#4CAF50'; // verde
        else if (nota >= 4) cor = '#FFC107'; // amarelo

        let animacao = setInterval(() => {
            if (largura >= (nota * 10)) {
                clearInterval(animacao);
            } else {
                largura++;
                barra.style.width = largura + '%';
                barra.style.background = cor;
            }
        }, 20);
    }

    // fechar modal
    document.querySelector('.fechar').onclick = function() {
        document.getElementById('resultadoModal').style.display = 'none';
    }
    window.onclick = function(event) {
        let modal = document.getElementById('resultadoModal');
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    }
    </script>
    ";
}
?>

</body>
</html>
